package org.sarahEckenrode.caseManager.repositories;



import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.sarahEckenrode.caseManager.models.Contact;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class RepositoryTests {

//	@Autowired
//	private ContactRepository repo;
//	
//	@Test
//	public void testCreateContact() {
//		Contact savedContact = repo.save(new Contact("Bob"));
//		assertThat(savedContact.getid()).isGreaterThan(0);
//	}
}
